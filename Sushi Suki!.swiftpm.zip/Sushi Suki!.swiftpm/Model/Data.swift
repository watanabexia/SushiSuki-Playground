//
//  Data.swift
//  
//
//  Created by 夏同光 on 4/18/23.
//

var rice = Source(name: "rice", kanji: "米", kana: "ごめ", romaji: "gome", assetName: "food_kome_masu")

var syari = Ingredient(name: "syari", assetName: "sushi_syari", source: rice, type: .syari)
