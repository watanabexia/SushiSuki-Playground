//
//  SourceView.swift
//  
//
//  Created by 夏同光 on 4/18/23.
//

import SwiftUI

struct SourceView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SourceView_Previews: PreviewProvider {
    static var previews: some View {
        SourceView()
    }
}
